About
=====

This package contains MCUXpresso projects allowing to demonstrate PN7160 support.


Details
===========

 * Support for NCI2.0 based PN7160 NXP's NFC Controller
 * Support LPC82X and LPC55S6x NXP's Microcontoller Units from LPC family
 * Support for i.MX RT1170 NXP's Crossover Processors from i.MX RT familly
 * Demonstrates:
    o NFC Forum and MIFARE Classic tags NDEF reading
    o NFC Forum T2T, T4T, T5T and MIFARE Classic tag NDEF writing
    o Raw tag (non-NDEF) access (MIFARE Classic, ISO14443-4, ISO14443-3A and ISO15693)
    o Multiple tags support (up to 2 of the same technology or multi-protocol card)
    o P2P (NDEF message exchange through NFC Forum SNEP protocol) 
    o Type 4 Tag Emulation (NDEF reading and writing as well as raw access)
    o PN7160 secure FW update (only in LPC55S6x MCUXpresso project)

Installation
============

Follow instructions from PN7160 NXP-NCI2.0 MCUXpresso examples guide: https://www.nxp.com/doc/AN13288


History
=======
 * v1.1: PN7160 firmware version 12.50.06 included
         FW update recovery added in case of uncompleted previous sequence
 * v1.0: First release
