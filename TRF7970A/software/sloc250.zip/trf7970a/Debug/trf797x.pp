# FIXED

trf797x.obj: ../trf797x.c
trf797x.obj: ../trf797x.h
trf797x.obj: ../mcu.h
trf797x.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
trf797x.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
trf797x.obj: ../msp430f23x0.h
trf797x.obj: ../types.h
trf797x.obj: ../parallel.h
trf797x.obj: ../spi.h
trf797x.obj: ../uart.h
trf797x.obj: ../nfc.h

../trf797x.c: 
../trf797x.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
../nfc.h: 
