# FIXED

nfc.obj: ../nfc.c
nfc.obj: ../nfc.h
nfc.obj: ../mcu.h
nfc.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
nfc.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
nfc.obj: ../msp430f23x0.h
nfc.obj: ../types.h
nfc.obj: ../trf797x.h
nfc.obj: ../parallel.h
nfc.obj: ../spi.h
nfc.obj: ../uart.h
nfc.obj: ../initiator.h
nfc.obj: ../target.h

../nfc.c: 
../nfc.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
../initiator.h: 
../target.h: 
