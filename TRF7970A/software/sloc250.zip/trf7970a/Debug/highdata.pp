# FIXED

highdata.obj: ../highdata.c
highdata.obj: ../highdata.h
highdata.obj: ../mcu.h
highdata.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
highdata.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
highdata.obj: ../msp430f23x0.h
highdata.obj: ../types.h
highdata.obj: ../trf797x.h
highdata.obj: ../parallel.h
highdata.obj: ../spi.h
highdata.obj: ../uart.h

../highdata.c: 
../highdata.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
