# FIXED

parallel.obj: ../parallel.c
parallel.obj: ../parallel.h
parallel.obj: ../mcu.h
parallel.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
parallel.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
parallel.obj: ../msp430f23x0.h
parallel.obj: ../types.h
parallel.obj: ../trf797x.h
parallel.obj: ../spi.h
parallel.obj: ../uart.h

../parallel.c: 
../parallel.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../spi.h: 
../uart.h: 
