# FIXED

target.obj: ../target.c
target.obj: ../target.h
target.obj: ../mcu.h
target.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
target.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
target.obj: ../msp430f23x0.h
target.obj: ../types.h
target.obj: ../nfc.h
target.obj: ../trf797x.h
target.obj: ../parallel.h
target.obj: ../spi.h
target.obj: ../uart.h
target.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/stdlib.h
target.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/linkage.h

../target.c: 
../target.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../nfc.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/stdlib.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/linkage.h: 
