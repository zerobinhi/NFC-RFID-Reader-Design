# FIXED

initiator.obj: ../initiator.c
initiator.obj: ../initiator.h
initiator.obj: ../mcu.h
initiator.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
initiator.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
initiator.obj: ../msp430f23x0.h
initiator.obj: ../types.h
initiator.obj: ../nfc.h
initiator.obj: ../trf797x.h
initiator.obj: ../parallel.h
initiator.obj: ../spi.h
initiator.obj: ../uart.h

../initiator.c: 
../initiator.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../nfc.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
