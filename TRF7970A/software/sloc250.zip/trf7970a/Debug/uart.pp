# FIXED

uart.obj: ../uart.c
uart.obj: ../uart.h
uart.obj: ../mcu.h
uart.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
uart.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
uart.obj: ../msp430f23x0.h
uart.obj: ../types.h
uart.obj: ../trf797x.h
uart.obj: ../parallel.h
uart.obj: ../spi.h

../uart.c: 
../uart.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
