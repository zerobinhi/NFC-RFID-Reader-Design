# FIXED

spi.obj: ../spi.c
spi.obj: ../spi.h
spi.obj: ../mcu.h
spi.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
spi.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
spi.obj: ../msp430f23x0.h
spi.obj: ../types.h
spi.obj: ../trf797x.h
spi.obj: ../parallel.h
spi.obj: ../uart.h

../spi.c: 
../spi.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../uart.h: 
