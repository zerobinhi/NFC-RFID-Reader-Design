# FIXED

tag.obj: ../tag.c
tag.obj: ../tag.h
tag.obj: ../mcu.h
tag.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
tag.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
tag.obj: ../msp430f23x0.h
tag.obj: ../types.h
tag.obj: ../nfc.h
tag.obj: ../trf797x.h
tag.obj: ../parallel.h
tag.obj: ../spi.h
tag.obj: ../uart.h
tag.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/stdlib.h
tag.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/linkage.h

../tag.c: 
../tag.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../nfc.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/stdlib.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include/linkage.h: 
