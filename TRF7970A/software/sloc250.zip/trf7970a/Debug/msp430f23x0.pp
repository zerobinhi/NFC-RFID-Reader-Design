# FIXED

msp430f23x0.obj: ../msp430f23x0.c
msp430f23x0.obj: ../msp430f23x0.h
msp430f23x0.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
msp430f23x0.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
msp430f23x0.obj: ../types.h
msp430f23x0.obj: ../trf797x.h
msp430f23x0.obj: ../mcu.h
msp430f23x0.obj: ../parallel.h
msp430f23x0.obj: ../spi.h
msp430f23x0.obj: ../uart.h

../msp430f23x0.c: 
../msp430f23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../types.h: 
../trf797x.h: 
../mcu.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
