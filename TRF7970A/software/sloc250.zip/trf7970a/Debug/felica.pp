# FIXED

felica.obj: ../felica.c
felica.obj: ../felica.h
felica.obj: ../mcu.h
felica.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
felica.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
felica.obj: ../msp430f23x0.h
felica.obj: ../types.h
felica.obj: ../trf797x.h
felica.obj: ../parallel.h
felica.obj: ../spi.h
felica.obj: ../uart.h

../felica.c: 
../felica.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
