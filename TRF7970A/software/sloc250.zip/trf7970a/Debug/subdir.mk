################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../felica.c \
../highdata.c \
../host.c \
../initiator.c \
../iso14443a.c \
../iso14443b.c \
../iso15693.c \
../main.c \
../mcu.c \
../msp430f23x0.c \
../nfc.c \
../parallel.c \
../spi.c \
../tag.c \
../target.c \
../trf797x.c \
../type2.c \
../uart.c 

CMD_SRCS += \
../lnk_msp430f2370.cmd 

OBJS += \
./felica.obj \
./highdata.obj \
./host.obj \
./initiator.obj \
./iso14443a.obj \
./iso14443b.obj \
./iso15693.obj \
./main.obj \
./mcu.obj \
./msp430f23x0.obj \
./nfc.obj \
./parallel.obj \
./spi.obj \
./tag.obj \
./target.obj \
./trf797x.obj \
./type2.obj \
./uart.obj 

C_DEPS += \
./felica.pp \
./highdata.pp \
./host.pp \
./initiator.pp \
./iso14443a.pp \
./iso14443b.pp \
./iso15693.pp \
./main.pp \
./mcu.pp \
./msp430f23x0.pp \
./nfc.pp \
./parallel.pp \
./spi.pp \
./tag.pp \
./target.pp \
./trf797x.pp \
./type2.pp \
./uart.pp 

OBJS__QTD += \
".\felica.obj" \
".\highdata.obj" \
".\host.obj" \
".\initiator.obj" \
".\iso14443a.obj" \
".\iso14443b.obj" \
".\iso15693.obj" \
".\main.obj" \
".\mcu.obj" \
".\msp430f23x0.obj" \
".\nfc.obj" \
".\parallel.obj" \
".\spi.obj" \
".\tag.obj" \
".\target.obj" \
".\trf797x.obj" \
".\type2.obj" \
".\uart.obj" 

C_DEPS__QTD += \
".\felica.pp" \
".\highdata.pp" \
".\host.pp" \
".\initiator.pp" \
".\iso14443a.pp" \
".\iso14443b.pp" \
".\iso15693.pp" \
".\main.pp" \
".\mcu.pp" \
".\msp430f23x0.pp" \
".\nfc.pp" \
".\parallel.pp" \
".\spi.pp" \
".\tag.pp" \
".\target.pp" \
".\trf797x.pp" \
".\type2.pp" \
".\uart.pp" 

C_SRCS_QUOTED += \
"../felica.c" \
"../highdata.c" \
"../host.c" \
"../initiator.c" \
"../iso14443a.c" \
"../iso14443b.c" \
"../iso15693.c" \
"../main.c" \
"../mcu.c" \
"../msp430f23x0.c" \
"../nfc.c" \
"../parallel.c" \
"../spi.c" \
"../tag.c" \
"../target.c" \
"../trf797x.c" \
"../type2.c" \
"../uart.c" 


# Each subdirectory must supply rules for building sources it contributes
felica.obj: ../felica.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="felica.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

highdata.obj: ../highdata.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="highdata.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

host.obj: ../host.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="host.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

initiator.obj: ../initiator.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="initiator.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

iso14443a.obj: ../iso14443a.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="iso14443a.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

iso14443b.obj: ../iso14443b.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="iso14443b.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

iso15693.obj: ../iso15693.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="iso15693.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

main.obj: ../main.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="main.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

mcu.obj: ../mcu.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="mcu.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

msp430f23x0.obj: ../msp430f23x0.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="msp430f23x0.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

nfc.obj: ../nfc.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="nfc.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

parallel.obj: ../parallel.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="parallel.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

spi.obj: ../spi.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="spi.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

tag.obj: ../tag.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="tag.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

target.obj: ../target.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="target.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

trf797x.obj: ../trf797x.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="trf797x.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

type2.obj: ../type2.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="type2.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '

uart.obj: ../uart.c $(GEN_OPTS) $(GEN_SRCS)
	@echo 'Building file: $<'
	@echo 'Invoking: Compiler'
	"C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/bin/cl430" -vmsp -g --define=__MSP430F2370__ --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/msp430/include" --include_path="C:/Program Files/Texas Instruments/CCS_V4/ccsv4/tools/compiler/msp430/include" --diag_warning=225 --printf_support=minimal --preproc_with_compile --preproc_dependency="uart.pp" $(GEN_OPTS_QUOTED) $(subst #,$(wildcard $(subst $(SPACE),\$(SPACE),$<)),"#")
	@echo 'Finished building: $<'
	@echo ' '


