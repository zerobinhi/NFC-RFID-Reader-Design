# FIXED

iso14443a.obj: ../iso14443a.c
iso14443a.obj: ../iso14443a.h
iso14443a.obj: ../mcu.h
iso14443a.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
iso14443a.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
iso14443a.obj: ../msp430f23x0.h
iso14443a.obj: ../types.h
iso14443a.obj: ../trf797x.h
iso14443a.obj: ../parallel.h
iso14443a.obj: ../spi.h
iso14443a.obj: ../uart.h

../iso14443a.c: 
../iso14443a.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
