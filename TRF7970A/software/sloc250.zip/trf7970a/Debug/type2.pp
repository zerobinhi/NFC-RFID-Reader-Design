# FIXED

type2.obj: ../type2.c
type2.obj: ../type2.h
type2.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
type2.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
type2.obj: ../mcu.h
type2.obj: ../msp430f23x0.h
type2.obj: ../types.h
type2.obj: ../trf797x.h
type2.obj: ../parallel.h
type2.obj: ../spi.h
type2.obj: ../uart.h

../type2.c: 
../type2.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../mcu.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
