# FIXED

iso15693.obj: ../iso15693.c
iso15693.obj: ../iso15693.h
iso15693.obj: ../mcu.h
iso15693.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h
iso15693.obj: C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h
iso15693.obj: ../msp430f23x0.h
iso15693.obj: ../types.h
iso15693.obj: ../trf797x.h
iso15693.obj: ../parallel.h
iso15693.obj: ../spi.h
iso15693.obj: ../uart.h

../iso15693.c: 
../iso15693.h: 
../mcu.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/MSP430x23x0.h: 
C:/Program\ Files/Texas\ Instruments/CCS_V4/ccsv4/msp430/include/in430.h: 
../msp430f23x0.h: 
../types.h: 
../trf797x.h: 
../parallel.h: 
../spi.h: 
../uart.h: 
