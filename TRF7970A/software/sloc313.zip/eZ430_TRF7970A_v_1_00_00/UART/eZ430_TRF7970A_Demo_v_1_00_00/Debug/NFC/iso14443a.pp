# FIXED

NFC/iso14443a.obj: ../NFC/iso14443a.c
NFC/iso14443a.obj: ../NFC/iso14443a.h
NFC/iso14443a.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/MSP430.h
NFC/iso14443a.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h
NFC/iso14443a.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h
NFC/iso14443a.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/mcu.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/Trf7970BoosterPack.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/types.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/mcu.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/trf7970.h
NFC/iso14443a.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h
NFC/iso14443a.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/NFC/iso14443a.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/spi.h
NFC/iso14443a.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/uart.h

../NFC/iso14443a.c: 
../NFC/iso14443a.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/MSP430.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/mcu.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/Trf7970BoosterPack.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/types.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/mcu.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/trf7970.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/NFC/iso14443a.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/spi.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/uart.h: 
