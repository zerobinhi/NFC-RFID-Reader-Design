# FIXED

Hardware/uart.obj: ../Hardware/uart.c
Hardware/uart.obj: ../Hardware/uart.h
Hardware/uart.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h
Hardware/uart.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h
Hardware/uart.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h
Hardware/uart.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h
Hardware/uart.obj: ../Hardware/mcu.h
Hardware/uart.obj: ../Hardware/Trf7970BoosterPack.h
Hardware/uart.obj: ../Hardware/types.h
Hardware/uart.obj: ../Hardware/mcu.h
Hardware/uart.obj: ../Hardware/trf7970.h
Hardware/uart.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h
Hardware/uart.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h
Hardware/uart.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/NFC/iso14443a.h
Hardware/uart.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/trf7970.h
Hardware/uart.obj: ../Hardware/spi.h

../Hardware/uart.c: 
../Hardware/uart.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h: 
../Hardware/mcu.h: 
../Hardware/Trf7970BoosterPack.h: 
../Hardware/types.h: 
../Hardware/mcu.h: 
../Hardware/trf7970.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/NFC/iso14443a.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/UART/eZ430_TRF7970A_Demo_v_1_00_00/Hardware/trf7970.h: 
../Hardware/spi.h: 
