/*
 * {main.c}
 *
 * {Behaves as I2C to UART Bridge}
 *
 * Copyright (C) {2014} Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

//******************************************************************************
//  Firmware for the I2C to UART Bridge on the MSP430G2553 Launch Pad.
//  Rev. # 1.00.00 -- 28.May.2014
//
//  RF430 NFC Booster Pack (Host/Master)
//
//  RF430 User Address Map
//  -----------------------------------------
//  Address		| Size	| Description		|
//  -----------------------------------------
//  0xFFFE		| 2B	| Control Register	|
//  0xFFFC		| 2B	| Status Register	|
//  0xFFFA		| 2B	| Interrupt Enable	|
//  0xFFF8		| 2B	| Interrupt Flags	|
//  0xFFF6		| 2B	| CRC Result		|
//  0xFFF4		| 2B	| CRC Length		|
//  0xFFF2		| 2B	| CRC Start Address	|
//  0xFFF0		| 2B	| Comm WD Ctrl Reg	|
//  -----------------------------------------
//  0x0000 - 	| 2kB	| NDEF App Memory	|
//    0x07FF	|		|					|
//
//  Description: This demo demonstrates RF430 read/write accesses via the I2C bus.
//	This is the code for the tester/host processor, which is the MASTER. This master
//  can send read and write commands over I2C to access the data structure in the
//	RF430 device. The following formats are used:
//
//	Write Access:
//	The master transmits a 2 byte address, then transmits N 16 bit values MSB first
//	to be stored by RF430 in locations starting at this address and incrementing.
//
//	Read Access:
//	The master transmits a 2 byte address, then receives back from RF430
//  the two bytes RF430 has stored at this location, MSB first.
//
//	Continuous Read Access:
//	The master receives the N bytes stored in RF430 starting at the next address
//	(next address = the last accessed address + 2) and incrementing, MSB first.
//
//
//                                /|\  /|\	  (Host/Tester)
//                   RF430        10k  10k     MSP430G2553
//                  (Slave)        |    |        Master
//             _________________   |    |   _________________
//            |              SDA|<-|----+->|P1.7/UCB0SDA  XIN|-+
//            |                 |  | I2C   |                 |
//            |              SCL|<-+------>|P1.6/UCB0SCL XOUT|-
//            |                 |          |                 |
//      GND<--|E(2-0)       /RST|<---------|P1.3*            | (* NOTE: Will be moved on next hardware revision.)
//            |             INTO|--------->|P2.7*            |
//            |                 |          |             P1.0|---->LED1
//            |                 |          |                 |
//            |_________________|          |_________________|
//
//
//AUTHOR:   J.D. Crutchfield	DATE: 28 MAY 2014
//
// BUILT WITH:
// Code Composer Studio Core Edition Version: 5.5.0.00077
// (C) Copyright Texas Instruments, 2009. All rights reserved.
//******************************************************************************

#include "msp430.h"
#include "Host.h"
#include "uart.h"

void MCU_Init(void);

unsigned char into_fired = 0;
unsigned char Tag_Data[200];

void main (void)
{
	volatile unsigned int test = 0;
	unsigned char i;

	MCU_Init();

	__delay_cycles(8000);
	UartSendCString("Reader enabled.");
	UartPutCrlf();

	__delay_cycles(4000000);

	__bis_SR_register(GIE);				// General enable interrupts

    while (1)
    {
    	PORT_INTO_IFG &= ~INTO; 		//clear any pending flags
    	PORT_INTO_IE |= INTO;			//enable interrupt

    	__bis_SR_register(LPM3_bits); 	//go to low power mode and enable interrupts. We are waiting for an NFC read or write of/to the RF430
    	__no_operation();
    	HEARTBEAT;						//Toggle heartbeat LED

    	if(into_fired)					//NFC/RFID INTO Fire?
    	{
    		Read_Continuous(&Tag_Data[0]);  // Read Tag Data
    		__delay_cycles(4000);

    		for(i=0; i<Tag_Data[0]; i++){
    			UartPutChar(Tag_Data[i+1]);
    		}

    		into_fired = 0; 			// INTO has been serviced
			__no_operation();
    	}
    }
}

void MCU_Init(void){
	WDTCTL = WDTPW | WDT_ADLY_16;

	IE1 |= WDTIE;							// Enable WDT interrupt

	if (CALBC1_8MHZ==0xFF)					// If calibration constant erased
	{
		while(1);                           // Do not load, trap CPU!!
	}
	else{
		DCOCTL = 0x00;
		BCSCTL1 = CALBC1_8MHZ;              // Set range
		DCOCTL = CALDCO_8MHZ;				// SMCLK = MCLK = DCO = 8 MHz	ACLK = LF oscillator
	}

	// Disable XT1 high frequency mode ACLK = 12kHz/8 = 1.5kHz for WDT
	BCSCTL1 &= ~XTS;
	BCSCTL1 |= DIVA_3;

	// Set XT1 to VLO
	BCSCTL3 |= LFXT1S_2;

	I2C_Init();
	GPIO_Init();
	UartSetup();
}

#pragma vector=PORT2_VECTOR					// INTO Signal from NFC/RFID Module
__interrupt void PORT2_ISR(void)
{
	if(PORT_INTO_IFG & INTO)
	{
		into_fired = 1;

		PORT_INTO_IE &= ~INTO; //disable INTO
		PORT_INTO_IFG &= ~INTO; //clear interrupt flag

		__bic_SR_register_on_exit(LPM3_bits); //wake up to handle INTO
	}
}

// Watchdog Timer interrupt service routine
#pragma vector=WDT_VECTOR
__interrupt void watchdog_timer(void)
{
   __bic_SR_register_on_exit(LPM3_bits);
}

#pragma vector = PORT1_VECTOR,ADC10_VECTOR,NMI_VECTOR,TIMER0_A1_VECTOR, \
		   TIMER0_A0_VECTOR, COMPARATORA_VECTOR, TIMER1_A1_VECTOR, TIMER1_A0_VECTOR, \
		   USCIAB0TX_VECTOR, USCIAB0RX_VECTOR
 __interrupt void ISR_trap(void)
 {
   while(1);  // IT'S A TRAP!!! (ISR)
 }

