/*
 * {host.c}
 *
 * {Hardware Initialization}
 *
 * Copyright (C) {2014} Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "msp430.h"
#include "Host.h"

void I2C_Init(void){
    // Configure pins for I2C
	PORT_I2C_SEL0 |= (SCL + SDA);			// Selecting I2C pin function
    PORT_I2C_SEL1 |= (SCL + SDA);

    //configure USCI for I2C
	UCB0CTL1 |= UCSWRST;	            	// Software reset enabled
	UCB0CTL0 |= UCMODE_3  + UCMST + UCSYNC; // I2C mode, Master mode, sync
	UCB0CTL1 |= UCSSEL_3 + UCSWRST;            // SMCLK = 8MHz, transmitter
	UCB0BR0 = 35; 							// Baudrate = SMLK/80 = 100kHz
	UCB0I2CSA  = 0x28;		    		// slave address - determined by pins E0, E1, and E2 on the RF430CL330H
	UCB0CTL1  &= ~UCSWRST;					// Software reset released
}

void GPIO_Init(void){
	//configure LED
	PORT_LED_SEL0 &= ~LED1; 				// Confirming GPIO pin functionality
	PORT_LED_SEL1 &= ~LED1;
	PORT_LED_DIR |= LED1; 					// Set as Output
	PORT_LED_OUT &= ~LED1; 					// Start LED off

	//configure pin for INTO interrupt
	PORT_INTO_SEL0 &= ~INTO; 				// Confirming GPIO pin functionality
	PORT_INTO_SEL1 &= ~INTO;
	PORT_INTO_DIR &= ~INTO; 				// Set as Input
	PORT_INTO_OUT |= INTO; 					// Set output register high
	PORT_INTO_REN |= INTO; 					// Internal pull-up resistor
	PORT_INTO_IFG &= ~INTO; 				// Clear interrupt flag
	PORT_INTO_IES |= INTO; 					// Set interrupt trigger as high-to-low transition, since INTO will be setup active low below
}

void Read_Continuous(unsigned char* read_data)
{
	unsigned int i = 0, data_length = 0;

	UCB0CTL1  &= ~UCSWRST;
	UCB0CTL1 |= UCTXSTT;			//start i2c read operation.  Sending Slave address

	while(!(IFG2 & UCB0RXIFG));

	data_length = UCB0RXBUF;  		// First Byte is Data_length
	read_data[0] = data_length;		// Need length for pushing to UART

	if(data_length > 1){
		for(i = 1; i < data_length; i++)
		{
			while(!(IFG2 & UCB0RXIFG));
			read_data[i] = UCB0RXBUF;
		}
	}
	UCB0CTL1 |= UCTXSTP; 			//send stop after next RX
	while(!(IFG2 & UCB0RXIFG));
	read_data[i] = UCB0RXBUF;
	while((UCB0STAT & UCBBUSY));    // Ensure stop condition got sent
	UCB0CTL1  |= UCSWRST;
}



