################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../lnk_msp430g2553.cmd 

C_SRCS += \
../Host.c \
../main.c \
../uart.c 

OBJS += \
./Host.obj \
./main.obj \
./uart.obj 

C_DEPS += \
./Host.pp \
./main.pp \
./uart.pp 

C_DEPS__QUOTED += \
"Host.pp" \
"main.pp" \
"uart.pp" 

OBJS__QUOTED += \
"Host.obj" \
"main.obj" \
"uart.obj" 

C_SRCS__QUOTED += \
"../Host.c" \
"../main.c" \
"../uart.c" 


