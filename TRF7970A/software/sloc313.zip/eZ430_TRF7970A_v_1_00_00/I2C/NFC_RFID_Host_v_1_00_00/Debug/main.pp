# FIXED

main.obj: ../main.c
main.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h
main.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h
main.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h
main.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h
main.obj: ../Host.h
main.obj: ../uart.h

../main.c: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h: 
../Host.h: 
../uart.h: 
