/*
 * {uart.c}
 *
 * {UART Interface Functions}
 *
 * Copyright (C) 2013 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/****************************************************************
* FILENAME: uart.c
*
* BRIEF: Contains functions to initialize UART interface using
* USCI_A0 and communicate with the host via this interface.
*
* Copyright (C) 2010 Texas Instruments, Inc.
*
* AUTHOR(S): Reiser Peter        START DATE: 20 SEP 2010
*
* EDITED BY:
* *
*
****************************************************************/

#include "uart.h"
//#include "trf7970.h"

//===============================================================

#if TRIGGER
    extern unsigned char trigger;
#endif

unsigned char rx_data = 0;                        // RS232 RX data byte
unsigned char rx_done = 0;
extern unsigned char i_reg;
extern unsigned char irq_flag;
extern unsigned char host_control_flag;
extern unsigned char stand_alone_flag;
extern unsigned char enable;

//===============================================================


//===============================================================
// 02DEC2010    RP    Original Code
//===============================================================

void
UartPutChar(unsigned char tx_char)
{
    while(!(IFG2 & UCA0TXIFG))                // till UART Transmit buffer is empty
    {
    }

    UCA0TXBUF = tx_char;                        // send the character
}

//===============================================================
// 02DEC2010    RP    Original Code
//===============================================================

void
UartPutCrlf(void)
{
    UartPutChar('\r');
    UartPutChar('\n');
}

//===============================================================
// Send a character string to USART                             ;
// 02DEC2010    RP    Original Code
//===============================================================

void
UartSendCString(char *pstr)
{
    while(*pstr != '\0')
    {
        UartPutChar(*pstr++);
    }
}

//===============================================================
// communication with host via USCI_A0                          ;
// 02DEC2010    RP    Original Code
//===============================================================

void
UartSetup (void)                            // uses USCI_A0
{
    P1SEL |= BIT1 + BIT2 ;                     // P1.1 = RXD, P1.2=TXD
    P1SEL2 |= BIT1 + BIT2 ;                    // P1.1 = RXD, P1.2=TXD
  
    UCA0CTL1 |= UCSWRST;                    // disable UART

    UCA0CTL0 = 0x00;

    UCA0CTL1 |= UCSSEL_2;                   // SMCLK
    
    UCA0BR0 = 0x41;
    UCA0BR1 = 0x03;
    UCA0MCTL = 0x92;               // Modulation UCBRSx = 2

    UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
}


