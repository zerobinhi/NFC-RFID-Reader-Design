# FIXED

NFC/iso15693.obj: ../NFC/iso15693.c
NFC/iso15693.obj: ../NFC/iso15693.h
NFC/iso15693.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h
NFC/iso15693.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h
NFC/iso15693.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h
NFC/iso15693.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/eZ430_TRF7970A.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/types.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/trf7970.h
NFC/iso15693.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h
NFC/iso15693.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC/iso14443a.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/trf7970.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/i2c.h
NFC/iso15693.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/spi.h

../NFC/iso15693.c: 
../NFC/iso15693.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/eZ430_TRF7970A.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/types.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/trf7970.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC/iso14443a.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/trf7970.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/i2c.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/spi.h: 
