# FIXED

Hardware/trf7970.obj: ../Hardware/trf7970.c
Hardware/trf7970.obj: ../Hardware/trf7970.h
Hardware/trf7970.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h
Hardware/trf7970.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h
Hardware/trf7970.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h
Hardware/trf7970.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h
Hardware/trf7970.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h
Hardware/trf7970.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC/iso14443a.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/eZ430_TRF7970A.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/types.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/trf7970.h
Hardware/trf7970.obj: C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/i2c.h
Hardware/trf7970.obj: ../Hardware/spi.h

../Hardware/trf7970.c: 
../Hardware/trf7970.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/stdlib.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/linkage.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC/iso14443a.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/eZ430_TRF7970A.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/types.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/mcu.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/trf7970.h: 
C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430\ Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware/i2c.h: 
../Hardware/spi.h: 
