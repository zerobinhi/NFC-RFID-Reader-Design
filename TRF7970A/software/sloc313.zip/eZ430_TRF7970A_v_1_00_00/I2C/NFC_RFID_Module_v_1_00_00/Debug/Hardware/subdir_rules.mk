################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
Hardware/eZ430_TRF7970A.obj: ../Hardware/eZ430_TRF7970A.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: MSP430 Compiler'
	"C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/bin/cl430" -vmsp --abi=coffabi -O0 --include_path="C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include" --include_path="C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC" -g --define=__MSP430G2553__ --define=ENABLE_HOST --define=ENABLE15693 --define=ENABLE14443A --define=ENABLE14443B --define=TRF7970A --diag_warning=225 --display_error_number --printf_support=minimal --preproc_with_compile --preproc_dependency="Hardware/eZ430_TRF7970A.pp" --obj_directory="Hardware" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

Hardware/i2c.obj: ../Hardware/i2c.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: MSP430 Compiler'
	"C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/bin/cl430" -vmsp --abi=coffabi -O0 --include_path="C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include" --include_path="C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC" -g --define=__MSP430G2553__ --define=ENABLE_HOST --define=ENABLE15693 --define=ENABLE14443A --define=ENABLE14443B --define=TRF7970A --diag_warning=225 --display_error_number --printf_support=minimal --preproc_with_compile --preproc_dependency="Hardware/i2c.pp" --obj_directory="Hardware" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

Hardware/spi.obj: ../Hardware/spi.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: MSP430 Compiler'
	"C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/bin/cl430" -vmsp --abi=coffabi -O0 --include_path="C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include" --include_path="C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC" -g --define=__MSP430G2553__ --define=ENABLE_HOST --define=ENABLE15693 --define=ENABLE14443A --define=ENABLE14443B --define=TRF7970A --diag_warning=225 --display_error_number --printf_support=minimal --preproc_with_compile --preproc_dependency="Hardware/spi.pp" --obj_directory="Hardware" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

Hardware/trf7970.obj: ../Hardware/trf7970.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: MSP430 Compiler'
	"C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/bin/cl430" -vmsp --abi=coffabi -O0 --include_path="C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include" --include_path="C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/Hardware" --include_path="C:/Users/a0273119/CCS_5.2_workspaces/embedded-rf/Radios/TRF7970A_64_A/MSP430G2553/EZ430 Boards/eZ430_TRF7970A_v_1_00_00/I2C/NFC_RFID_Module_v_1_00_00/NFC" -g --define=__MSP430G2553__ --define=ENABLE_HOST --define=ENABLE15693 --define=ENABLE14443A --define=ENABLE14443B --define=TRF7970A --diag_warning=225 --display_error_number --printf_support=minimal --preproc_with_compile --preproc_dependency="Hardware/trf7970.pp" --obj_directory="Hardware" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '


