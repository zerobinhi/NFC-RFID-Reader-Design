# FIXED

Hardware/i2c.obj: ../Hardware/i2c.c
Hardware/i2c.obj: ../Hardware/i2c.h
Hardware/i2c.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h
Hardware/i2c.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h
Hardware/i2c.obj: C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h
Hardware/i2c.obj: C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h
Hardware/i2c.obj: ../Hardware/mcu.h
Hardware/i2c.obj: ../Hardware/eZ430_TRF7970A.h
Hardware/i2c.obj: ../Hardware/types.h
Hardware/i2c.obj: ../Hardware/mcu.h

../Hardware/i2c.c: 
../Hardware/i2c.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/msp430g2553.h: 
C:/TI/CCS5.5/ccsv5/ccs_base/msp430/include/in430.h: 
C:/TI/CCS5.5/ccsv5/tools/compiler/msp430_4.2.1/include/intrinsics.h: 
../Hardware/mcu.h: 
../Hardware/eZ430_TRF7970A.h: 
../Hardware/types.h: 
../Hardware/mcu.h: 
