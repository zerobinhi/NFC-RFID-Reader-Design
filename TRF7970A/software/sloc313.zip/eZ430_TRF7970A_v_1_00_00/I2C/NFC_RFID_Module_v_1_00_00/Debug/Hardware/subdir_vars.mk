################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/eZ430_TRF7970A.c \
../Hardware/i2c.c \
../Hardware/spi.c \
../Hardware/trf7970.c 

OBJS += \
./Hardware/eZ430_TRF7970A.obj \
./Hardware/i2c.obj \
./Hardware/spi.obj \
./Hardware/trf7970.obj 

C_DEPS += \
./Hardware/eZ430_TRF7970A.pp \
./Hardware/i2c.pp \
./Hardware/spi.pp \
./Hardware/trf7970.pp 

C_DEPS__QUOTED += \
"Hardware\eZ430_TRF7970A.pp" \
"Hardware\i2c.pp" \
"Hardware\spi.pp" \
"Hardware\trf7970.pp" 

OBJS__QUOTED += \
"Hardware\eZ430_TRF7970A.obj" \
"Hardware\i2c.obj" \
"Hardware\spi.obj" \
"Hardware\trf7970.obj" 

C_SRCS__QUOTED += \
"../Hardware/eZ430_TRF7970A.c" \
"../Hardware/i2c.c" \
"../Hardware/spi.c" \
"../Hardware/trf7970.c" 


