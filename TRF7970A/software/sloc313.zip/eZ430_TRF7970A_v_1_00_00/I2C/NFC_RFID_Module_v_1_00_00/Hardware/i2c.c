/*
 * {i2c.c}
 *
 * {I2C related functions}
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/* This source file was used for communicating between MSP430 and host,
 *to make MSP430 looks like RF430 in all responses */

#include "i2c.h"

volatile unsigned char g_i2c_finished_flag;
volatile unsigned char TXByteCtr;

// Set up initial condition for I2C communication on MSP430G2553
void I2c_setup(void)
{
	  P1SEL |= BIT6 + BIT7;                     // Assign I2C pins to USCI_B0
	  P1SEL2|= BIT6 + BIT7;                     // Assign I2C pins to USCI_B0
	  UCB0CTL1 |= UCSWRST;                      // Enable SW reset
	  UCB0CTL0 = UCMODE_3 + UCSYNC;             // I2C Slave, synchronous mode
	  UCB0I2COA = 0x28;                         // Own Address is 0x28
	  UCB0CTL1 &= ~UCSWRST;                     // Clear SW reset, resume operation
	  UCB0I2CIE |= UCSTPIE + UCSTTIE;           // Enable STT and STP interrupt
	  IE2 |= UCB0RXIE | UCB0TXIE;               // Enable RX/TX interrupt

      __bis_SR_register(GIE);
}

//------------------------------------------------------------------------------
// Transfer Tag Data back to a host via I2C
//------------------------------------------------------------------------------
void I2C_Transfer(void)
{
	unsigned char i=0;
//	i2c_flag = 0;
	g_i2c_finished_flag = 0;
	TXByteCtr = 0;
	INTO_LOW;

	i = 0;
	while((!g_i2c_finished_flag) && (i < 250)){  	// Wait for master to start I2C
		McuDelayMillisecond(1);
		i++;							// 250 ms timeout
	}

	INTO_HIGH;
	McuDelayMillisecond(1);
}

//------------------------------------------------------------------------------
// The USCI_B0 data ISR is used to move received data from the I2C master
// to the MSP430 memory.  Is fired based on UCB0TXIFG & UCB0RXIFG
//------------------------------------------------------------------------------
#pragma vector = USCIAB0TX_VECTOR  // Just Received ISR
__interrupt void USCIAB0TX_ISR(void)
{
	if(TXByteCtr == 0){  // Transmit Length
		UCB0TXBUF = g_TagDataPointer;
	}
	else{				// Transmit Data
		UCB0TXBUF = g_TagData[TXByteCtr-1];
	}

	TXByteCtr++;
}

//------------------------------------------------------------------------------
// The USCI_B0 state ISR is used to wake up the CPU from LPM0 in order to
// process the received data in the main program. LPM0 is only exit in case
// of a (re-)start or stop condition when actual data was received.
// Fired upon STT and STP Flags.
//------------------------------------------------------------------------------
#pragma vector = USCIAB0RX_VECTOR  // READ ISR
__interrupt void USCIAB0RX_ISR(void)
{
	if( UCB0STAT & UCSTTIFG){  // Start

	}
	else{ // UCSTPIFG Stop
		g_i2c_finished_flag = 1;
	}

	UCB0STAT &= ~(UCSTPIFG + UCSTTIFG);  // Clear all Flags
}










//#include "uart.h"
//#include "trf7970.h"

//===============================================================

//#if TRIGGER
//    extern u08_t trigger;
//#endif

//u08_t rx_data = 0;                        // RS232 RX data byte
//u08_t rx_done = 0;
//extern u08_t i_reg;
//extern u08_t irq_flag;
//extern u08_t host_control_flag;
//extern u08_t stand_alone_flag;
//extern u08_t enable;

extern unsigned char g_TagData[200];
extern unsigned char g_TagDataPointer;
//extern volatile unsigned char g_TagDataLength;

//===============================================================

//u08_t UartNibble2Ascii(u08_t anibble);

//===============================================================
// 02DEC2010    RP    Original Code
//===============================================================

//===============================================================
// convert a nibble to ASCII hex byte                           ;
// output a binary coded byte as two hex coded ascii bytes      ;
// 02DEC2010    RP    Original Code
//===============================================================

u08_t
I2cNibble2Ascii(u08_t anibble)
{
    u08_t    ascii_out = anibble;

    if(anibble > 9)                            // If req ASCII A-F then add 7(hex)
    {
        ascii_out = ascii_out + 0x07;
    }

    // Add offset to convert to Ascii
    ascii_out = ascii_out + 0x30;

    return(ascii_out);
}

//===============================================================
// 02DEC2010    RP    Original Code
//===============================================================

void
I2cBuffPutByte(u08_t abyte)
{
    u08_t    temp1 = 0, temp2 = 0;

    temp1 = (abyte >> 4) & 0x0F;            // get high nibble
    temp2 = I2cNibble2Ascii(temp1);        // convert to ASCII
    I2cBuffPutChar(temp2);                        // output */

    temp1 = abyte & 0x0F;                    // get low nibble
    temp2 = I2cNibble2Ascii(temp1);        // convert to ASCII
    I2cBuffPutChar(temp2);                        // output
}

//===============================================================
// 02DEC2010    RP    Original Code
//===============================================================

void
I2cBuffPutChar(u08_t tx_char)
{
	g_TagData[g_TagDataPointer++] = tx_char;
}

//===============================================================
// 02DEC2010    RP    Original Code
//===============================================================

void
I2cBuffPutCrlf(void)
{
	I2cBuffPutChar('\r');
	I2cBuffPutChar('\n');
}


//===============================================================
// Send a character string to USART                             ;
// 02DEC2010    RP    Original Code
//===============================================================

void
I2cBuffPutString(char *pstr)
{
    while(*pstr != '\0')
    {
    	I2cBuffPutChar(*pstr++);
    }
}

