/*
 * {main.c}
 *
 * {main application}
 *
 * Copyright (C) 2013 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/****************************************************************
* Firmware for the eZ430-TRF7970A Module with the MSP430G2553.
* Rev. # 1.0 -- 28.May.2014
*
* DESCRIPTION: This Example detects 15693, Type A, and Type B, and Felica NFC tags.
* It then indicates Tags found by an INTO signal to be used by a I2C Master.
* The UID and the RSSI (field strength) are sent out via a I2C
* and can be read on a Computer if hooked to a I2C to USB bridge.
*
* The Trf7970 is an integrated analog front end and
* data framing system for a 13.56 MHz RFID reader system.
* Built-in programming options make it suitable for a wide range
* of applications both in proximity and vicinity RFID systems.
* The reader is configured by selecting the desired protocol in
* the control registers. Direct access to all control registers
* allows fine tuning of various reader parameters as needed.
*
* The Trf7970A is interfaced to a MSP430F2553 through a SPI (serial)
* interface using a hardware USCI. The MCU is the master device and
* initiates all communication with the reader.
*
* The anti-collision procedures (as described in the ISO
* standards 14443A/B and 15693) are implemented in the MCU
* firmware to help the reader detect and communicate with one
* PICC/VICC among several PICCs/VICCs.
*
*
* AUTHOR:   J.D. Crutchfield	DATE: 28 MAY 2014
*
* BUILT WITH:
* Code Composer Studio Core Edition Version: 5.5.0.00077
* (C) Copyright Texas Instruments, 2009. All rights reserved.
*****************************************************************/

//===============================================================
// Program with hardware USART and SPI communication	        ;
// interface with TRF7970A reader chip.                         ;
//                                                              ;
// PORT1.0 - HEART BEAT LED                                     ;
// PORT1.1 - UART RX                                            ;
// PORT1.2 - UART TX                                            ;
// PORT1.5 - SPI DATACLK                                        ;
// PORT1.6 - SPI MISO (REMOVE LED2 JUMPER)                      ;
// PORT1.7 - SPI MOSI                                           ;
//                                                              ;
// PORT2.0 - IRQ (INTERUPT REQUEST from TRF7970A)               ;
// PORT2.1 - SLAVE SELECT                                       ;
// PORT2.2 - TRF7970A ENABLE                                    ;
// PORT2.3 - ISO14443B LED                                      ;
// PORT2.4 - ISO14443A LED                                      ;
// PORT2.5 - ISO15693  LED                                      ;
//===============================================================

/********** HEADER FILES **********/
//===============================================================
#include <msp430.h>                         // processor specific header
#include <stdlib.h>                         // general purpose standard library
#include <stdio.h>                          // standard input/output header
#include "iso14443a.h"
#include "iso14443b.h"
#include "iso15693.h"
#include "felica.h"
#include "mcu.h"
#include "Trf7970.h"
#include "types.h"
#include "i2c.h"
//===============================================================

unsigned char g_TagData[200];       // Buffer for storing I2C String (before sending out via I2C
unsigned char g_TagDataPointer;

/********** GLOBAL NFC VARIABLES **********/
//===============================================================
u08_t buf[100];					// TX/RX BUFFER FOR TRF7970A
u08_t enable = 0;
u08_t Tag_Count;
u08_t i_reg = 0x01;             // INTERRUPT REGISTER
u08_t irq_flag = 0x00;
u08_t rx_error_flag = 0x00;
s08_t rxtx_state = 1;           // USED FOR TRANSMIT RECEIVE BYTE COUNT
u08_t host_control_flag = 0;
u08_t stand_alone_flag = 1;
unsigned int i, j;
//===============================================================

void main(void)
{
	WDTCTL = WDT_ADLY_16;	// Setup WDT to blink heartbeat/wake up MCU
	IE1 |= WDTIE;			// Enable WDT interrupt

	McuOscSel(1);			// set the DCO to 8 MHz

	INTO_HIGH;
	INTO_PORT_SET;

	// Give Module time to get up and running
	McuDelayMillisecond(50);

	// Setup SPI for TRF7970A Communication
	Trf7970CommunicationSetup();

	// Set Clock Frequency and Modulation
	Trf7970InitialSettings();

	I2c_setup();

	enable = 1;				// indicates that setting are done
	stand_alone_flag = 1;	// stand alone mode

	IRQ_OFF;
	DISABLE_TRF;

	while(1)
	{
		g_TagDataPointer = 0;
		Tag_Count = 0;

		// Enter LPM3
		__bis_SR_register(LPM3_bits);

		// Clear IRQ Flags before enabling TRF7970A
		P2OUT &= ~0x01;
		IRQ_CLR;
		IRQ_ON;

		ENABLE_TRF;

		// Must wait at least 4.8 ms to allow TRF7970A to initialize.
		__delay_cycles(40000);

		#ifdef ENABLE15693
			 Iso15693FindTag();		// Scan for 15693 tags
		#endif

		#ifdef ENABLE14443A
			  Iso14443aFindTag();	// Scan for 14443A tags
		#endif

		#ifdef ENABLE14443B
			  Iso14443bFindTag();	// Scan for 14443B tags
		#endif

		#ifdef ENABLEFELICA
			  FindFelica();		// Scan for FeliCa tags
		#endif

		// Write total number of tags read to I2C
		if(Tag_Count > 0){

			//Need to get rid of these functions
			Tag_Count = I2cNibble2Ascii(Tag_Count & 0x0F);	// convert to ASCII
			I2cBuffPutString("Tags Found: ");
			I2cBuffPutChar(Tag_Count);
			I2cBuffPutCrlf();
			I2cBuffPutCrlf();

			I2C_Transfer();
		}

		IRQ_OFF;
		DISABLE_TRF;
	}
}

// Watchdog Timer interrupt service routine
#pragma vector=WDT_VECTOR
__interrupt void watchdog_timer(void)
{
   __bic_SR_register_on_exit(LPM3_bits);   //exit LPM3
}

/************* IT'S A TRAP!!!! (ISR'S) **************/
//====================================================
#pragma vector= PORT1_VECTOR
__interrupt void PORT1_ISR (void)
{
	while(1);
}

#pragma vector= ADC10_VECTOR
__interrupt void ADC12_ISR (void)
{
	while(1);
}

#pragma vector= TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR (void)
{
	while(1);
}

#pragma vector= COMPARATORA_VECTOR
__interrupt void COMPARATORA_ISR (void)
{
	while(1);
}

#pragma vector= TIMER1_A1_VECTOR
__interrupt void TIMER1_A1_ISR (void)
{
	while(1);
}

#pragma vector= TIMER1_A0_VECTOR
__interrupt void TIMER1_A0_ISR (void)
{
	while(1);
}

#pragma vector= NMI_VECTOR
__interrupt void NMI_ISR (void)
{
	while(1);
}
//===============================================================


