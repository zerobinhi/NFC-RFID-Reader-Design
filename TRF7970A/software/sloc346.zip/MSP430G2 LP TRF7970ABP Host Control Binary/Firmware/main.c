/*
 * main.c
 *
 * Copyright (C) 2017 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

//#include <MSP430x23x0.h> 	// processor specific header
#include <stdlib.h>			// general purpose standard library
#include <stdio.h>			// standard input/output header
#include "host.h"
#include "iso15693.h"
#include "mcu.h"
#include "trf797x.h"
#include "types.h"
#include "uart.h"

//===============================================================

u08_t buf[BUF_LENGTH];

u08_t enable = 0;

u08_t i_reg = 0x01;							// interrupt register

u08_t irq_flag = 0x00;
u08_t rx_error_flag = 0x00;
s08_t rxtx_state = 1;							// used for transmit recieve byte count

s16_t nfc_state;

u08_t remote_flag = 0;
u08_t stand_alone_flag = 1;
u08_t reader_mode = 0x00;					// determines how interrups will be handled

//===============================================================
//
//===============================================================

void main (void)	{
	
	// Settings
	WDTCTL = WDTPW + WDTHOLD;			// stop watchdog timer
	
	McuDelayMillisecond(2);				// wait until system clock started

	SLAVE_SELECT_PORT_SET;							// P3.0 - Slave Select
	SLAVE_SELECT_HIGH;

	#ifdef ENABLE_HOST
		UartSetup();					// settings for UART
	#endif

	McuDelayMillisecond(3);				// wait until system clock started

	ENABLE_SET;							// P1.0 is switched in output direction
	TRF_ENABLE;

	Trf797xCommunicationSetup();		// settings for communication with TRF

	McuDelayMillisecond(1);				// wait until system clock started
		
	Trf797xInitialSettings();			// Set MCU Clock Frequency to 6.78 MHz and OOK Modulation
	
	// Now switch from DCO to external 6.78 MHz clock

	McuOscSel(1);       				// set the oscillator 8 Mhz
	McuDelayMillisecond(10);

	 UartPutChar('a');
	
	// Re-configure the USART with this external clock

	//Trf797xReConfig();
     	
	ENABLE_INTERRUPTS;					// General enable interrupts

    //Launchpad version (AK)
    //	LED_POWER_ON;						// board ist powered, green LED
    
	//Launchpad version (AK)
	//OOK_DIR_IN;							// set OOK port tristate
	enable = 1;							// indicates, that setting are done

	reader_mode = 0x00;
	stand_alone_flag = 0;				// stand alone mode
	remote_flag = 0;					// host is not active
    //	Settings done
    
	while(1)							// infinite loop
	{	
		#if TRIGGER						// in Mcu.h
			LED_OPEN1_ON;
			McuDelayMillisecond(1);
			LED_OPEN1_OFF;
		#endif
		if(remote_flag == 1) 			// if in remote mode
		{								// remote mode can be disabled in host.h
			#ifdef ENABLE_HOST
				buf[4] = 0xff;			// "TRF7960 EVM" message in GUI
				stand_alone_flag = 0;
				LED_ALL_OFF;
                //Launchpad version (AK)
                //				LED_POWER_ON;
				HostCommands();			// device works according host commands
			#endif
		}
		else
		{	
			#ifdef ENABLE15693				// this standard can be disabled in ISO15693.h
				Iso15693FindTag();			// detects ISO15693 in stand-alone mode
			#endif
		}
	}
}
