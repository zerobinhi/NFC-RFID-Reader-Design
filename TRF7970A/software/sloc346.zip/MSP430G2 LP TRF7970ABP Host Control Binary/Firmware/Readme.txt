====================================================================================
       MSP430G2 LaunchPad and TRF7970ABP Combo Host Control Firmware
====================================================================================

This binary is meant to be used with the RF430FRL152HEVM PC GUI available here: 
http://www.ti.com/lit/zip/slac692

What this binary allows is host control of ISO15693 RFID commands such as 
read/write single block as well as custom commands using the combination of
these two tools:

1.  MSP430 LaunchPad Value Line Development kit
    http://www.ti.com/tool/msp-exp430g2
2.  NFC Transceiver Booster Pack
    http://www.ti.com/tool/dlp-7970abp
    
It should be programmed to the MSP430 LaunchPad using a tool such as UniFlash:
http://www.ti.com/tool/UNIFLASH
